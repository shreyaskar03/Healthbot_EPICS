// Example: Basic form validation before submission
document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("form");

    form.addEventListener("submit", (event) => {
        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;
        const age = document.getElementById("age").value;

        // Simple validation example
        if (!name || !email || !password || !age) {
            event.preventDefault(); // Prevent form submission
            alert("All fields are required!");
            return;
        }

        if (password.length < 6) {
            event.preventDefault();
            alert("Password must be at least 6 characters long.");
            return;
        }
    });
});
