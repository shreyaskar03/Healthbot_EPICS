const express = require("express");
const bodyParser = require("body-parser");
const { Pool } = require("pg");

const app = express();
const port = 3000;

// Middleware to parse form data
app.use(bodyParser.urlencoded({ extended: true }));

// PostgreSQL connection configuration
const pool = new Pool({
  user: "postgres",
  host: "localhost",
  database: "user_info",
  password: "Shreyaskar",
  port: 5432,
});

// Route to handle form submission
app.post("/submit", async (req, res) => {
  const { name, email, password, gender, age } = req.body;

  try {
    const query = `
      INSERT INTO users (name, email, password, gender, age)
      VALUES ($1, $2, $3, $4, $5)
    `;
    await pool.query(query, [name, email, password, gender, age]);
    res.send("User data saved successfully!");
  } catch (error) {
    console.error("Error saving user data:", error);
    res.status(500).send("An error occurred while saving the data.");
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
